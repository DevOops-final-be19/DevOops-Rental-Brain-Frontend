// src/api/customerSummaryAnalysis.js
import api from '@/api/axios';

// 1) KPI(5개 카드)
export const getCustomerSummaryKpi = (month) =>
  api.get('/customerSummaryAnalysis/kpi', { params: { month } });

// 2) 월별 이탈 위험률 차트
export const getMonthlyRiskRate = (from, to) =>
  api.get('/customerSummaryAnalysis/risk-monthly-rate', { params: { from, to } });

// 3) 만족도 분포(1~5)
export const getSatisfactionDist = () =>
  api.get('/customerSummaryAnalysis/satisfaction');

// 4) 세그먼트 분포(파이)
export const getSegmentDistribution = () =>
  api.get('/customerSummaryAnalysis/segment-distribution');

// (선택) 이탈 KPI 카드 따로
export const getRiskKpi = (month) =>
  api.get('/customerSummaryAnalysis/riskKpi', { params: { month } });

// (선택) 만족도 별 회사 목록(페이징)
export const getSatisfactionCustomers = (star, page = 1, size = 10) =>
  api.get(`/customerSummaryAnalysis/satisfaction/${star}/customers`, {
    params: { page, size },
  });
