<template>
    <div class="page">
        <h1>프로모션 목록</h1>
    </div>
</template>

<script setup>
</script>
