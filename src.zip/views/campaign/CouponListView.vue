<template>
    <div class="page">
        <h1>쿠폰 목록</h1>
    </div>
</template>

<script setup>
</script>
