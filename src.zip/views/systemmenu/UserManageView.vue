<template>
    <div>
        <h1>회원별 관리 리스트</h1>
        <p>여기에 회원별 관리 목록이 표시됩니다.</p>
    </div>
</template>

<script setup>
</script>

<style scoped></style>
