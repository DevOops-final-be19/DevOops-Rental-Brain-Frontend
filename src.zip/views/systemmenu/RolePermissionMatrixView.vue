<template>
    <div>
        <h1>권한관리 리스트</h1>
        <p>여기에 권한관리 목록이 표시됩니다.</p>
    </div>
</template>

<script setup>
</script>

<style scoped></style>
