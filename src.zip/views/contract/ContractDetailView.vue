<template>
    <div class="page">
        <h1>계약 상세 페이지</h1>
    </div>
</template>

<script setup>
</script>
