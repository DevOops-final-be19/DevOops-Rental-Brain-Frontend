<template>
    <div class="page">
        <h1>계약 목록</h1>
    </div>
</template>

<script setup>
</script>
