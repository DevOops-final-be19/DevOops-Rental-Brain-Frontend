<template>
    <div>
        <h1>고객 분석 – 응대 분석</h1>
        <p>여기에 고객 세그먼트 분석 차트가 들어갑니다.</p>
    </div>
</template>

<script setup>
</script>

<style scoped></style>
