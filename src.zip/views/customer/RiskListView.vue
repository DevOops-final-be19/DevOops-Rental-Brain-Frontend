<template>
    <div class="page">
        <h1>연체관리</h1>
    </div>
</template>

<script setup>
</script>
