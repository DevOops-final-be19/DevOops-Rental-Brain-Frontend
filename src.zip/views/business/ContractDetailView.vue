<template>
    <div>
        <h1>계약 상세 리스트</h1>
        <p>여기에 계약 상세 목록이 표시됩니다.</p>
    </div>
</template>

<script setup>
</script>

<style scoped></style>
