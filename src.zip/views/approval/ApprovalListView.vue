<template>
    <div class="page">
        <h1>전자 결재 목록</h1>
    </div>
</template>

<script setup>
</script>
